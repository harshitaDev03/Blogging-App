# Blogging-Platform
Create a feature-rich blogging platform with added subscription functionality.  Content Management . in python Django project.
cd your-django-project
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
than run admin add category , and also subs. plan deatails 
than You can add post according to your plan.


